import pefile
import graphviz

def sanitize_section_name(name):
    # Replace invalid characters in the section name with underscores
    return ''.join(c if c.isalnum() or c == '_' else '_' for c in name)

def visualize_pe_sections(pe):
    dot = graphviz.Digraph(comment='PE Sections')
    
    for section in pe.sections:
        name = sanitize_section_name(section.Name.decode().strip())
        start = hex(section.VirtualAddress)
        size = hex(section.Misc_VirtualSize)
        label = f'{name}\nStart: {start}\nSize: {size}'
        
        dot.node(name, label)
    
    # Save the graph and open it
    output_file = 'pe_sections_graph'
    dot.render(output_file, format='pdf', view=True)  # You can also use format='png'

def parse_pe(file_path):
    pe = pefile.PE(file_path)
    
    print(f'Entry Point: {hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint)}')
    print(f'Number of Sections: {len(pe.sections)}')
    
    for section in pe.sections:
        name = section.Name.decode().strip()
        start = hex(section.VirtualAddress)
        size = hex(section.Misc_VirtualSize)
        print(f'Section {name}: {start} - {size}')
    
    visualize_pe_sections(pe)

if __name__ == '__main__':
    parse_pe('/Users/mounikaraj/Documents/HelloWorld.exe')  # Update the path as needed
